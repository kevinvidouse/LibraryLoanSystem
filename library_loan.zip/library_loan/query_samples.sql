----- 1. Number of copies of a particular library items

define name='gat' --- write name of the item here

select items.id,items.name,count(c.id) as number_of_copies
from copies c
join items on items.id = c.ITEM_ID
where lower(items.NAME) like '%'||lower('&name')||'%'
group by items.id,items.name

----- 2. List of patrons who have at least one overdue item today

select p.id as patron_id
    ,p.first_name
    ,p.last_name
    ,count(l.id) as amount_of_overdue_copies
from patrons p
join loans l on p.id = l.patrons_id
where nvl(l.actual_return_date,sysdate) > l.due_date
group by p.id
    ,p.first_name
    ,p.last_name

----- 3. Total fine owed by patron by library card number

define library_card_number = '6555 0811 3946 0485'

select p.id
    ,p.first_name
    ,p.last_name
    ,p.card_number
    ,round(sum((case when (nvl(l.actual_return_date,sysdate) - due_date) < 0 then 0 else (nvl(l.actual_return_date,sysdate) - due_date) end) * cat.fine_per_day - nvl(payments.amount,0)),2) as debt
from patrons p
join loans l on l.patrons_id = p.id and p.card_number = '&library_card_number'
join copies c on c.id = l.copies_id
join items i on i.id = c.item_id
join category cat on cat.id = i.category_id
left join payments on payments.LOANS_ID = l.id
where l.actual_return_date is null or l.actual_return_date > l.due_date
group by p.id,p.first_name
    ,p.last_name
    ,p.card_number

----- 4.  List the details of the payment made by patron

select pat.id
    ,pat.first_name
    ,pat.last_name
    ,nvl(d_c.name,'Overdue Fine Payment') "Reason"
    ,pay.amount
    ,pay.date_add as "Date of payment"
from payments pay
join patrons pat on pat.id = pay.patrons_id
left join damages d on d.id = pay.damages_id
left join dic_condition d_c on d_c.id = d.condition
order by pat.id

----- 5. List of copies that are grossly overdue

define number_of_days=3

select c.*
from copies c
join loans l on l.copies_id = c.id
where sysdate - l.due_date > '&number_of_days' and l.actual_return_date is not null

----- 6. Details of current pending requests

select *
from requests
where status = 1

----- 7. Total fine revenue to the library between March 1, 2012 an March 31, 2012

select sum(amount) finr_revenue
from payments
where date_add between to_date('01.03.2012','dd.mm.yyyy') and to_date('31.03.2012','dd.mm.yyyy')

----- 8. List of details of the checkout periods and the number of renewals for all categories of items

select p.id
    ,p.last_name || ' ' ||p.first_name
    ,i.name
    ,sum(l.renewals_used)
from patrons p
join loans l on p.id = l.patrons_id
join copies c on c.id = l.copies_id
join items i on i.id = c.item_id
where l.RENEWALS_USED > 0
group by p.id
    ,p.last_name || ' ' ||p.first_name
    ,i.name

----- 9. Total number and details of library items that are checked out and renewed by patron

select p.id
    ,p.last_name || ' ' ||p.first_name
    ,i.name
from patrons p
join loans l on p.id = l.patrons_id
join copies c on c.id = l.copies_id
join items i on i.id = c.item_id
where l.RENEWALS_USED > 0
order by p.id

----- 9. Insert new pending request

insert into requests (patrons_id,items_id) values ((select max(id) from patrons), (select min(id) from copies where status = 2))
